import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-created',
  templateUrl: './user-created.component.html',
  styleUrls: ['./user-created.component.css']
})
export class UserCreatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
