import { ShopAssistentGuard } from './shop-assistent-guard';

describe('ShopAssistentGuard', () => {
  it('should create an instance', () => {
    expect(new ShopAssistentGuard()).toBeTruthy();
  });
});
