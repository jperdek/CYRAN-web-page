import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-methods-set',
  templateUrl: './delivery-methods-set.component.html',
  styleUrls: ['./delivery-methods-set.component.css']
})
export class DeliveryMethodsSetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
