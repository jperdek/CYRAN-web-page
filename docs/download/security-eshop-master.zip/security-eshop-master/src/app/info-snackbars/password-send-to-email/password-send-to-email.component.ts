import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-password-send-to-email',
  templateUrl: './password-send-to-email.component.html',
  styleUrls: ['./password-send-to-email.component.css']
})
export class PasswordSendToEmailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
