import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-logged-out',
  templateUrl: './user-logged-out.component.html',
  styleUrls: ['./user-logged-out.component.css']
})
export class UserLoggedOutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
