import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-added-to-chart',
  templateUrl: './added-to-chart.component.html',
  styleUrls: ['./added-to-chart.component.css']
})
export class AddedToChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
