import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bought-order-prepared',
  templateUrl: './bought-order-prepared.component.html',
  styleUrls: ['./bought-order-prepared.component.css']
})
export class BoughtOrderPreparedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
