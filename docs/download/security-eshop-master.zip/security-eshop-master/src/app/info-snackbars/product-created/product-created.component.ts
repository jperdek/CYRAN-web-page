import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-created',
  templateUrl: './product-created.component.html',
  styleUrls: ['./product-created.component.css']
})
export class ProductCreatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
