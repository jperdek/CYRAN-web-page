import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-logged-in',
  templateUrl: './user-logged-in.component.html',
  styleUrls: ['./user-logged-in.component.css']
})
export class UserLoggedInComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
