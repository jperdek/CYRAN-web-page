import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-payment-sent-to-email',
  templateUrl: './order-payment-sent-to-email.component.html',
  styleUrls: ['./order-payment-sent-to-email.component.css']
})
export class OrderPaymentSentToEmailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
