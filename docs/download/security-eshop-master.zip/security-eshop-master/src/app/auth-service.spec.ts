import { AuthService } from './auth-service';

describe('AuthService', () => {
  it('should create an instance', () => {
    expect(new AuthService()).toBeTruthy();
  });
});
