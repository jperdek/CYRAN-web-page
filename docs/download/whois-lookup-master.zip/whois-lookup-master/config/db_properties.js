module.exports = {
	host: 'localhost',
	user: "postgres",
	port: 5432,
	password: "perdek",
	databaseName: "postgres"
}