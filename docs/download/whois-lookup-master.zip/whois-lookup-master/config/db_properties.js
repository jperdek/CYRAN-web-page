

module.exports = {
	host: process.env.DB_HOST,
	user: "postgres",
	port: 5432,
	password: "perdekj",
	databaseName: "postgres"
}